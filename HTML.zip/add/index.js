$(document).ready(function() {
    $('#table').DataTable();
} );